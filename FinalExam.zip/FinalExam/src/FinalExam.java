import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.Component;
import javax.swing.JPanel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JTextField;

import java.awt.Panel;
import java.awt.ScrollPane;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.awt.event.ActionEvent;
import java.util.*;
import javax.swing.JTextArea;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;



public class FinalExam {

	private JFrame frame;
	
	private JTextField txtFldOptionM;
	private JTextField txtFldPhraseC;
	private JTextField txtFldPhraseL;
	private JTextField txtFldPhraseR;
	private JScrollPane scroll;
	private JTextArea txtAreaPhraseW;
	
	String phrase;
	String newTextPhrase;
	String pType;
	int phraseLength;
	int wordCount;
	

	ImageIcon Backgrd = new ImageIcon("C:/Users/marga/workspace/FinalExam/src/ropes3.gif"
			+ "");
	
	
	
	/**
	 * Launch the application.   
	 * 
	 * ********************* MAIN METHOD *****************
	 */	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FinalExam window = new FinalExam();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FinalExam() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() 
	{
		frame = new JFrame();
		frame.setBounds(100, 100, 944, 537);
		// Set to maximized height and width.
        //frame.setExtendedState(JFrame.MAXIMIZED_BOTH); 
		
		// get the screen size as a java dimension and then set screen accordingly
		//Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		//frame.setSize(screenSize.width, screenSize.height);
		 
		/* get 2/3 of the height, and 2/3 of the width
		int height = screenSize.height;
		int width = screenSize.width;
		Set the jframe height and width
		frame.setSize(screenSize.width * 2/3, screenSize.height * 2/3); 
		frame.setSize(screenSize.width/2, screenSize.height/2);
		frame.setPreferredSize(new Dimension(width, height));
		*/

		//frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new CardLayout(0, 0));
		
		
		// Create new object classes from external classes WordCount, Capitals, LowerCase, Reverse.  
		// Establish Constructor by passing variables
		
		ConvertText ctObj = new ConvertText(phrase);
			
	 
		// ************************** DECLARE JPANELS *************************************
		JPanel panelMain = new JPanel();
		frame.getContentPane().add(panelMain, "name_1201996593477838");
		panelMain.setLayout(null);
		
		Panel panelWords = new Panel();
		panelWords.setForeground(new Color(0, 0, 255));
		frame.getContentPane().add(panelWords, "name_167107823686084");
		panelWords.setLayout(null);
		
		JPanel panelCaps = new JPanel();
		panelCaps.setForeground(new Color(0, 0, 255));
		frame.getContentPane().add(panelCaps, "name_167475960510363");
		panelCaps.setLayout(null);
		
		JPanel panelLower = new JPanel();
		panelLower.setForeground(new Color(0, 0, 255));
		frame.getContentPane().add(panelLower, "name_167744644747651");
		panelLower.setLayout(null);
		
		JPanel panelReverse = new JPanel();
		panelReverse.setForeground(new Color(0, 0, 255));
		frame.getContentPane().add(panelReverse, "name_167856787938426");
		panelReverse.setLayout(null);
				
				 
				
				
				// ************************** MAIN MENU *************************************
		JLabel lblMHeading = new JLabel("**** STRING CONVERTER ****");
		lblMHeading.setForeground(new Color(0, 0, 255));
		lblMHeading.setFont(new Font("Tahoma", Font.BOLD, 28));
		lblMHeading.setBounds(219, 67, 461, 20);
		panelMain.add(lblMHeading);
		
		JLabel lblWords = new JLabel("1. Display Number of Words in String");
		lblWords.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblWords.setForeground(new Color(0, 0, 255));
		lblWords.setBounds(263, 129, 343, 20);
		panelMain.add(lblWords);
		
		JLabel lblCaps = new JLabel("2. Display String in All Capital Letters");
		lblCaps.setForeground(new Color(0, 0, 255));
		lblCaps.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblCaps.setBounds(263, 165, 343, 20);
		panelMain.add(lblCaps);
		
		JLabel lblLower = new JLabel("3. Display String in All Lowercase Letters");
		lblLower.setForeground(new Color(0, 0, 255));
		lblLower.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblLower.setBounds(263, 201, 375, 20);
		panelMain.add(lblLower);
		
		JLabel lblReverse = new JLabel("4. Display String in Reverse Order");
		lblReverse.setForeground(new Color(0, 0, 255));
		lblReverse.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblReverse.setBounds(263, 237, 316, 20);
		panelMain.add(lblReverse);
		
		JLabel lblExit = new JLabel("5. Exit");
		lblExit.setForeground(new Color(0, 0, 255));
		lblExit.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblExit.setBounds(263, 275, 78, 20);
		panelMain.add(lblExit);
		
		JLabel lblOptionM = new JLabel("Option:");
		lblOptionM.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblOptionM.setForeground(new Color(0, 0, 255));
		lblOptionM.setBounds(307, 332, 69, 20);
		panelMain.add(lblOptionM);
		
		JLabel lblErrMsgM = new JLabel(" ");
		lblErrMsgM.setForeground(new Color(204, 0, 0));
		lblErrMsgM.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblErrMsgM.setBounds(35, 433, 838, 20);
		panelMain.add(lblErrMsgM);
		
		txtFldOptionM = new JTextField();
		txtFldOptionM.setFont(new Font("Tahoma", Font.PLAIN, 18));
		txtFldOptionM.setBackground(new Color(0, 0, 255));
		txtFldOptionM.setForeground(new Color(255, 255, 0));
		txtFldOptionM.setBounds(407, 330, 69, 26);
		panelMain.add(txtFldOptionM);
		txtFldOptionM.setColumns(10);
				
		JButton btnMContinue = new JButton("Continue");
		btnMContinue.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnMContinue.setForeground(new Color(255, 255, 255));
		btnMContinue.setBackground(new Color(0, 102, 0));
		btnMContinue.setBounds(283, 388, 135, 29);
		panelMain.add(btnMContinue);
		btnMContinue.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				String option = txtFldOptionM.getText();
				try
				{ 
					int opt = Integer.parseInt(option);
					if ((opt < 1) || (opt > 5))
					{
						lblErrMsgM.setText("Invalid Option entered, Please re-enter (1-5)");
						panelMain.setVisible(true);
						txtFldOptionM.requestFocusInWindow();
						txtFldOptionM.setCaretPosition(0);
					} else
					{	
								
						switch(opt)
						{
						case 1:
							// Return the Number of Words
							lblErrMsgM.setText(null);
							panelMain.setVisible(false);
							panelReverse.setVisible(false);
							panelCaps.setVisible(false);
							panelLower.setVisible(false);
							panelWords.setVisible(true);
							//txtAreaPhraseW.setText(null);
							//txtAreaPhraseW.setCaretPosition(0);
							//txtAreaPhraseW.requestFocusInWindow();
							break;
						case 2:
							// Return in All Caps
							lblErrMsgM.setText(null);
							panelMain.setVisible(false);
							panelReverse.setVisible(false);
							panelWords.setVisible(false);
							panelLower.setVisible(false);
							panelCaps.setVisible(true);
							//txtFldPhraseC.setText(null);
							//txtFldPhraseC.setCaretPosition(0);
							//txtFldPhraseC.requestFocusInWindow();
							break;
						case 3:
							// Return in All Lowercase
							lblErrMsgM.setText(null);
							panelMain.setVisible(false);
							panelWords.setVisible(false);
							panelCaps.setVisible(false);
							panelReverse.setVisible(false);
							panelLower.setVisible(true);
							//txtFldPhraseL.setText(null);
							//txtFldPhraseL.setCaretPosition(0);
							//txtFldPhraseL.requestFocusInWindow();
							break;
						case 4:
							// Return in Reverse
							lblErrMsgM.setText(null);
							panelMain.setVisible(false);
							panelWords.setVisible(false);
							panelCaps.setVisible(false);
							panelLower.setVisible(false);
							panelReverse.setVisible(true);
							//txtFldPhraseR.setText(null);
							//txtFldPhraseR.setCaretPosition(0);
							//txtFldPhraseR.requestFocusInWindow();
							break;
						case 5:
							// Quit
							lblErrMsgM.setText(null);
							txtFldOptionM.setText(null);
							panelMain.setVisible(false);
							System.exit(0);
							break;
						default:
							lblErrMsgM.setText("Invalid Option entered, Please re-enter (1-5)");
					    	panelMain.setVisible(true);
							txtFldOptionM.requestFocusInWindow();
							txtFldOptionM.setCaretPosition(0);				
						} // END OF SWITCH
				
					} // END OF IF-ELSE FOR INVALID OPTION
				}
			    catch(NumberFormatException e1)
				{
			    	lblErrMsgM.setText("Option must be a numeric value");
			    	panelMain.setVisible(true);
					txtFldOptionM.requestFocusInWindow();
					txtFldOptionM.setCaretPosition(0);
				}	
					
			} // END OF ACTIONPERFORMED
	
		
		});
		
		JButton btnMQuit = new JButton("Quit");
		btnMQuit.setForeground(Color.WHITE);
		btnMQuit.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnMQuit.setBackground(new Color(204, 0, 0));
		btnMQuit.setBounds(519, 388, 135, 29);
		panelMain.add(btnMQuit);
		btnMQuit.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				lblErrMsgM.setText(null);
				txtFldOptionM.setText(null);
				panelMain.setVisible(false);
				System.exit(0);
			}
		});
		
		
		JLabel lblBackgroundImageM = new JLabel(Backgrd);
		lblBackgroundImageM.setForeground(new Color(0, 0, 204));
		lblBackgroundImageM.setBounds(0, 0, 944, 537);
		panelMain.add(lblBackgroundImageM);
		
		// ************************** NUMBER OF WORDS SCREEN *************************************		
				
		JLabel lblWHeading = new JLabel("**** STRING CONVERTER ****");
		lblWHeading.setForeground(new Color(0, 0, 255));
		lblWHeading.setFont(new Font("Tahoma", Font.BOLD, 28));
		lblWHeading.setBounds(219, 67, 461, 20);
		panelWords.add(lblWHeading);
		
		JLabel lblDirectW = new JLabel("Please enter the following information:");
		lblDirectW.setForeground(new Color(0, 0, 255));
		lblDirectW.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblDirectW.setBounds(100, 117, 485, 20);
		panelWords.add(lblDirectW);
						
		JLabel lblPhraseW = new JLabel("Phrase to Convert:");
		lblPhraseW.setForeground(new Color(0, 0, 255));
		lblPhraseW.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblPhraseW.setBounds(248, 170, 176, 20);
		panelWords.add(lblPhraseW);
		
		
		JTextArea txtAreaPhraseW = new JTextArea();
		txtAreaPhraseW.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtAreaPhraseW.setLineWrap(true);
		txtAreaPhraseW.setWrapStyleWord(true);
		JScrollPane scroll = new JScrollPane(txtAreaPhraseW, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scroll.setBounds(435, 171, 372, 109);
		panelWords.add(scroll);
		
		
		JLabel lblResponseW = new JLabel("The number of words in the phrase are:");
		lblResponseW.setForeground(new Color(0, 0, 255));
		lblResponseW.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblResponseW.setBounds(52, 302, 372, 20);
		panelWords.add(lblResponseW);
				
		
		JLabel lblWordCountW = new JLabel(" ");
		lblWordCountW.setBackground(Color.WHITE);
		lblWordCountW.setForeground(new Color(204, 0, 0));
		lblWordCountW.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblWordCountW.setBounds(435, 301, 146, 23);
		panelWords.add(lblWordCountW);
		
		
		JLabel lblErrMsgW = new JLabel(" ");
		lblErrMsgW.setForeground(new Color(204, 0, 0));
		lblErrMsgW.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblErrMsgW.setBounds(35, 433, 838, 20);
		panelWords.add(lblErrMsgW);
				
		
		JButton btnWContinue = new JButton("Continue");
		btnWContinue.setForeground(Color.WHITE);
		btnWContinue.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnWContinue.setBackground(new Color(0, 102, 0));
		btnWContinue.setBounds(284, 362, 135, 29);
		panelWords.add(btnWContinue);
		btnWContinue.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				
				try
				{
					phrase = (txtAreaPhraseW.getText());
					phraseLength = (phrase.length());
					if (phraseLength > 0)
						{	
							 ctObj.setPhraseVar(phrase);
							 wordCount = ctObj.getWordCount();
							 DecimalFormat decimalFormat = new DecimalFormat("#,##0");
							 String intAsString = decimalFormat.format(wordCount);
							 lblWordCountW.setText(intAsString);
						     // WordCountW.setText(areaString);
						     lblErrMsgW.setText(null);
						}     
						else
						{	
							lblWordCountW.setText(null);
							lblErrMsgW.setText("Please enter a phrase to convert to word count.");
						} 
				}
				   catch(NumberFormatException e1)
				{
				   	lblWordCountW.setText(null);
				   	lblErrMsgW.setText("Please enter a phrase to convert to word count.");
				}
							
			}  // End of Words Action Performed
			
		}); // End of Words Continue Button 
		
		
		JButton btnWCancel = new JButton("Return");
		btnWCancel.setForeground(Color.WHITE);
		btnWCancel.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnWCancel.setBackground(new Color(204, 0, 0));
		btnWCancel.setBounds(520, 362, 135, 29);
		panelWords.add(btnWCancel);
		btnWCancel.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				lblErrMsgM.setText(null);
				lblErrMsgW.setText(null);
				lblWordCountW.setText(null);
				txtAreaPhraseW.setText(null);
				txtFldOptionM.setText(null);
				panelMain.setVisible(true);
				//txtFldOption.setCaretPosition(0);
				txtFldOptionM.requestFocusInWindow();
				panelWords.setVisible(false);
				panelCaps.setVisible(false);
				panelLower.setVisible(false);
				panelReverse.setVisible(false);
			}   // End of Words Action Performed
			
		});
				
		 
		JLabel lblBackgroundImageW = new JLabel(Backgrd);
		lblBackgroundImageW.setForeground(new Color(0, 0, 204));
		lblBackgroundImageW.setBounds(0, 0, 944, 537);
		panelWords.add(lblBackgroundImageW);
		 
				
		// ************************** ALL CAPITALS SCREEN *************************************
		
		JLabel lblCHeading = new JLabel("**** STRING CONVERTER ****");
		lblCHeading.setForeground(new Color(0, 0, 255));
		lblCHeading.setFont(new Font("Tahoma", Font.BOLD, 28));
		lblCHeading.setBounds(219, 67, 461, 20);
		panelCaps.add(lblCHeading);
		
		JLabel lblDirectC = new JLabel("Please enter the following information:");
		lblDirectC.setForeground(new Color(0, 0, 255));
		lblDirectC.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblDirectC.setBounds(100, 117, 485, 20);
		panelCaps.add(lblDirectC);
						
		JLabel lblPhraseC = new JLabel("Phrase to Convert:");
		lblPhraseC.setForeground(new Color(0, 0, 255));
		lblPhraseC.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblPhraseC.setBounds(248, 170, 176, 20);
		panelCaps.add(lblPhraseC);
				
		JTextArea txtAreaPhraseC = new JTextArea();
		txtAreaPhraseC.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtAreaPhraseC.setLineWrap(true);
		txtAreaPhraseC.setWrapStyleWord(true);
		JScrollPane scrollC = new JScrollPane(txtAreaPhraseC, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollC.setBounds(435, 171, 372, 60);
		panelCaps.add(scrollC);
				
		JLabel lblResponseC = new JLabel("Phrase Converted To All CAPS:");
		lblResponseC.setForeground(new Color(0, 0, 255));
		lblResponseC.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblResponseC.setBounds(150, 276, 274, 20);
		panelCaps.add(lblResponseC);
		
		JTextArea txtAreaNewPhraseC = new JTextArea();
		txtAreaNewPhraseC.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtAreaNewPhraseC.setLineWrap(true);
		txtAreaNewPhraseC.setWrapStyleWord(true);
		JScrollPane newScrollC = new JScrollPane(txtAreaNewPhraseC, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		newScrollC.setBounds(435, 276, 372, 60);
		panelCaps.add(newScrollC);
		
		
		
		JLabel lblErrMsgC = new JLabel(" ");
		lblErrMsgC.setForeground(new Color(204, 0, 0));
		lblErrMsgC.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblErrMsgC.setBounds(35, 433, 838, 20);
		panelCaps.add(lblErrMsgC);
				
		
		JButton btnCContinue = new JButton("Continue");
		btnCContinue.setForeground(Color.WHITE);
		btnCContinue.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnCContinue.setBackground(new Color(0, 102, 0));
		btnCContinue.setBounds(170, 362, 135, 29);
		panelCaps.add(btnCContinue);
		btnCContinue.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				
				try
				{
					phrase = (txtAreaPhraseC.getText());
					phraseLength = (phrase.length());
					if (phraseLength > 0)
						{	
							 ctObj.setPhraseVar(phrase);
							 newTextPhrase = ctObj.getAllCaps();
							 txtAreaNewPhraseC.setText(newTextPhrase);
							 String printTextArea = (txtAreaNewPhraseC.getText());
							 System.out.println(printTextArea);
						     // txtAreaPhraseC.setText(areaString);
						     lblErrMsgC.setText(null);
						}     
						else
						{	
							txtAreaPhraseC.setText(null);
							lblErrMsgC.setText("Please enter a phrase to convert to all CAPS.");
						} 
				}
				   catch(NumberFormatException e1)
				{
					   txtAreaPhraseC.setText(null);
				   	lblErrMsgC.setText("Please enter a phrase to convert to all CAPS.");
				}
							
			}  // End of Caps Action Performed
			
		}); // End of Caps Continue Button 
		
		
		JButton btnClearC = new JButton("Clear");
		btnClearC.setForeground(Color.WHITE);
		btnClearC.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnClearC.setBackground(new Color(0, 102, 0));
		btnClearC.setBounds(382, 362, 135, 29);
		panelCaps.add(btnClearC);
		btnClearC.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				lblErrMsgC.setText(null);
				txtAreaPhraseC.setText(null);
				txtAreaNewPhraseC.setText(null);
				phrase = null;
				newTextPhrase = null;
				panelCaps.setVisible(true);
			}// End of All Caps Clear Action Performed
		});
		
		JButton btnCCancel = new JButton("Return");
		btnCCancel.setForeground(Color.WHITE);
		btnCCancel.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnCCancel.setBackground(new Color(204, 0, 0));
		btnCCancel.setBounds(610, 362, 135, 29);
		panelCaps.add(btnCCancel);
		btnCCancel.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				lblErrMsgM.setText(null);
				lblErrMsgC.setText(null);
				txtAreaPhraseC.setText(null);
				txtAreaNewPhraseC.setText(null);
				txtFldOptionM.setText(null);
				panelMain.setVisible(true);
				//txtFldOption.setCaretPosition(0);
				txtFldOptionM.requestFocusInWindow();
				panelCaps.setVisible(false);
				panelWords.setVisible(false);
				panelLower.setVisible(false);
				panelReverse.setVisible(false);
			}   // End of Caps Action Performed
			
		});
				
		 
		JLabel lblBackgroundImageC = new JLabel(Backgrd);
		lblBackgroundImageC.setForeground(new Color(0, 0, 204));
		lblBackgroundImageC.setBounds(0, 0, 944, 537);
		panelCaps.add(lblBackgroundImageC);
		
		
		// ************************** ALL LOWERCASE SCREEN *************************************				
		
		JLabel lblLHeading = new JLabel("**** STRING CONVERTER ****");
		lblLHeading.setForeground(new Color(0, 0, 255));
		lblLHeading.setFont(new Font("Tahoma", Font.BOLD, 28));
		lblLHeading.setBounds(219, 67, 461, 20);
		panelLower.add(lblLHeading);
		
		JLabel lblDirectL = new JLabel("Please enter the following information:");
		lblDirectL.setForeground(new Color(0, 0, 255));
		lblDirectL.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblDirectL.setBounds(100, 117, 485, 20);
		panelLower.add(lblDirectL);
						
		JLabel lblPhraseL = new JLabel("Phrase to Convert:");
		lblPhraseL.setForeground(new Color(0, 0, 255));
		lblPhraseL.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblPhraseL.setBounds(248, 170, 176, 20);
		panelLower.add(lblPhraseL);
				
		JTextArea txtAreaPhraseL = new JTextArea();
		txtAreaPhraseL.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtAreaPhraseL.setLineWrap(true);
		txtAreaPhraseL.setWrapStyleWord(true);
		JScrollPane scrollL = new JScrollPane(txtAreaPhraseL, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollL.setBounds(435, 171, 372, 60);
		panelLower.add(scrollL);
				
		JLabel lblResponseL = new JLabel("Phrase Converted To All Lowercase:");
		lblResponseL.setForeground(new Color(0, 0, 255));
		lblResponseL.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblResponseL.setBounds(100, 276, 324, 20);
		panelLower.add(lblResponseL);
		
		JTextArea txtAreaNewPhraseL = new JTextArea();
		txtAreaNewPhraseL.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtAreaNewPhraseL.setLineWrap(true);
		txtAreaNewPhraseL.setWrapStyleWord(true);
		JScrollPane newScrollL = new JScrollPane(txtAreaNewPhraseL, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		newScrollL.setBounds(435, 276, 372, 60);
		panelLower.add(newScrollL);
		
		
		
		JLabel lblErrMsgL = new JLabel(" ");
		lblErrMsgL.setForeground(new Color(204, 0, 0));
		lblErrMsgL.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblErrMsgL.setBounds(35, 433, 838, 20);
		panelLower.add(lblErrMsgL);
				
		
		JButton btnLContinue = new JButton("Continue");
		btnLContinue.setForeground(Color.WHITE);
		btnLContinue.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnLContinue.setBackground(new Color(0, 102, 0));
		btnLContinue.setBounds(170, 362, 135, 29);
		panelLower.add(btnLContinue);
		btnLContinue.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				
				try
				{
					phrase = (txtAreaPhraseL.getText());
					phraseLength = (phrase.length());
					if (phraseLength > 0)
						{	
							 ctObj.setPhraseVar(phrase);
							 newTextPhrase = ctObj.getAllLowerCase();
							 txtAreaNewPhraseL.setText(newTextPhrase);
							 String printTextArea = (txtAreaNewPhraseL.getText());
							 System.out.println(printTextArea);
						     // txtAreaPhraseL.setText(areaString);
						     lblErrMsgL.setText(null);
						}     
						else
						{	
							txtAreaPhraseL.setText(null);
							lblErrMsgL.setText("Please enter a phrase to convert to all lower case.");
						} 
				}
				   catch(NumberFormatException e1)
				{
					   txtAreaPhraseC.setText(null);
				   	lblErrMsgC.setText("Please enter a phrase to convert to all lower case.");
				}
							
			}  // End of Lowercase Action Performed
			
		}); // End of Lowercase Continue Button 
		
		JButton btnClearL = new JButton("Clear");
		btnClearL.setForeground(Color.WHITE);
		btnClearL.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnClearL.setBackground(new Color(0, 102, 0));
		btnClearL.setBounds(382, 362, 135, 29);
		panelLower.add(btnClearL);
		btnClearL.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				lblErrMsgL.setText(null);
				txtAreaPhraseL.setText(null);
				txtAreaNewPhraseL.setText(null);
				phrase = null;
				newTextPhrase = null;
				panelLower.setVisible(true);
			}// End of LowerCase Clear Action Performed
		});
		
		
		JButton btnLCancel = new JButton("Return");
		btnLCancel.setForeground(Color.WHITE);
		btnLCancel.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnLCancel.setBackground(new Color(204, 0, 0));
		btnLCancel.setBounds(610, 362, 135, 29);
		panelLower.add(btnLCancel);
		btnLCancel.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				lblErrMsgM.setText(null);
				lblErrMsgL.setText(null);
				txtAreaPhraseL.setText(null);
				txtAreaNewPhraseL.setText(null);
				txtFldOptionM.setText(null);
				panelMain.setVisible(true);
				//txtFldOption.setCaretPosition(0);
				txtFldOptionM.requestFocusInWindow();
				panelCaps.setVisible(false);
				panelWords.setVisible(false);
				panelLower.setVisible(false);
				panelReverse.setVisible(false);
			}   // End of Lowercase Action Performed
			
		});
				
		 
		JLabel lblBackgroundImageL = new JLabel(Backgrd);
		lblBackgroundImageL.setForeground(new Color(0, 0, 204));
		lblBackgroundImageL.setBounds(0, 0, 944, 537);
		panelLower.add(lblBackgroundImageL);
		
		
		// ************************** REVERSE PHRASE SCREEN *************************************			
		
		JLabel lblRHeading = new JLabel("**** STRING CONVERTER ****");
		lblRHeading.setForeground(new Color(0, 0, 255));
		lblRHeading.setFont(new Font("Tahoma", Font.BOLD, 28));
		lblRHeading.setBounds(219, 67, 461, 20);
		panelReverse.add(lblRHeading);
		
		JLabel lblDirectR = new JLabel("Please enter the following information:");
		lblDirectR.setForeground(new Color(0, 0, 255));
		lblDirectR.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblDirectR.setBounds(100, 117, 485, 20);
		panelReverse.add(lblDirectR);
						
		JLabel lblPhraseR = new JLabel("Phrase to Convert:");
		lblPhraseR.setForeground(new Color(0, 0, 255));
		lblPhraseR.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblPhraseR.setBounds(248, 170, 176, 20);
		panelReverse.add(lblPhraseR);
				
		JTextArea txtAreaPhraseR = new JTextArea();
		txtAreaPhraseR.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtAreaPhraseR.setLineWrap(true);
		txtAreaPhraseR.setWrapStyleWord(true);
		JScrollPane scrollR = new JScrollPane(txtAreaPhraseR, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollR.setBounds(435, 171, 372, 60);
		panelReverse.add(scrollR);
				
		JLabel lblResponseR = new JLabel("Phrase Converted To Reverse Order:");
		lblResponseR.setForeground(new Color(0, 0, 255));
		lblResponseR.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblResponseR.setBounds(94, 276, 330, 20);
		panelReverse.add(lblResponseR);
		
		JTextArea txtAreaNewPhraseR = new JTextArea();
		txtAreaNewPhraseR.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtAreaNewPhraseR.setLineWrap(true);
		txtAreaNewPhraseR.setWrapStyleWord(true);
		JScrollPane newscrollR = new JScrollPane(txtAreaNewPhraseR, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		newscrollR.setBounds(435, 276, 372, 60);
		panelReverse.add(newscrollR);
		
		
		
		JLabel lblErrMsgR = new JLabel(" ");
		lblErrMsgR.setForeground(new Color(204, 0, 0));
		lblErrMsgR.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblErrMsgR.setBounds(35, 433, 838, 20);
		panelReverse.add(lblErrMsgR);
				
		
		JButton btnRContinue = new JButton("Continue");
		btnRContinue.setForeground(Color.WHITE);
		btnRContinue.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnRContinue.setBackground(new Color(0, 102, 0));
		btnRContinue.setBounds(170, 362, 135, 29);
		panelReverse.add(btnRContinue);
		btnRContinue.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				
				try
				{
					phrase = (txtAreaPhraseR.getText());
					phraseLength = (phrase.length());
					if (phraseLength > 0)
						{	
							 ctObj.setPhraseVar(phrase);
							 newTextPhrase = ctObj.getReverseOrder();
							 txtAreaNewPhraseR.setText(newTextPhrase);
							 // txtAreaPhraseR.setText(areaString);
						     lblErrMsgR.setText(null);
						}     
						else
						{	
							txtAreaPhraseR.setText(null);
							lblErrMsgR.setText("Please enter a phrase to convert into Reverse Order.");
						} 
				}
				   catch(NumberFormatException e1)
				{
					   txtAreaPhraseC.setText(null);
				   	lblErrMsgC.setText("Please enter a phrase to convert into Reverse Order.");
				}
							
			}  // End of Reverse Order Action Performed
			
		}); // End of Reverse Order Continue Button 
		
		JButton btnClearR = new JButton("Clear");
		btnClearR.setForeground(Color.WHITE);
		btnClearR.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnClearR.setBackground(new Color(0, 102, 0));
		btnClearR.setBounds(382, 362, 135, 29);
		panelReverse.add(btnClearR);
		btnClearR.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				lblErrMsgR.setText(null);
				txtAreaPhraseR.setText(null);
				txtAreaNewPhraseR.setText(null);
				phrase = null;
				newTextPhrase = null;
				panelReverse.setVisible(true);
			}// End of Reverse Order Clear Action Performed
		});
		
		JButton btnRcancel = new JButton("Return");
		btnRcancel.setForeground(Color.WHITE);
		btnRcancel.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnRcancel.setBackground(new Color(204, 0, 0));
		btnRcancel.setBounds(610, 362, 135, 29);
		panelReverse.add(btnRcancel);
		btnRcancel.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				lblErrMsgM.setText(null);
				lblErrMsgR.setText(null);
				txtAreaPhraseR.setText(null);
				txtAreaNewPhraseR.setText(null);
				txtFldOptionM.setText(null);
				panelMain.setVisible(true);
				//txtFldOption.setCaretPosition(0);
				txtFldOptionM.requestFocusInWindow();
				panelCaps.setVisible(false);
				panelWords.setVisible(false);
				panelLower.setVisible(false);
				panelReverse.setVisible(false);
			}   // End of Reverse Order Action Performed
			
		});
				
		 
		JLabel lblBackgroundImageR = new JLabel(Backgrd);
		lblBackgroundImageR.setForeground(new Color(0, 0, 204));
		lblBackgroundImageR.setBounds(0, 0, 944, 537);
		panelReverse.add(lblBackgroundImageR);
	
	}  // END OF INITIALIZE
} // END OF CLASS FINAL EXAM
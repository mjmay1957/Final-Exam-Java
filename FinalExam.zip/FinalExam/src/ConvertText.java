
public class ConvertText 
{
	private String pType;
	private String phrase;
	String newPhrase;
	String finalPhrase;
	char newChar;
	int counter;
	int i2 = 0;
	int phraseLength = 0;
	char compChar;
	int convertChar;
	boolean b1;
	int previousChar;
	int firstChar;
	
	
	
	// Constructor
	public ConvertText(String p) 
	{
		phrase=p;
	}
	
	public void setPhraseType(String p)
	{
		phrase = p;
	}
	
	// Set the phrase to be used from the Phrase entered on the screen.
		public void setPhraseVar(String p)
		{
			phrase = p;
		}

		 
	public int getCountWords() 
	{
		// this does the same as the method getWordCount.  getWordCount is actual logic instead of a
		// predefined command.
		String [] tokens = phrase.split(" ");
		counter = tokens.length;
		return counter;
	}
	
	// This code edits out multiple whitespace between words!
	public int getWordCount() 
	{
		counter = 1;
		firstChar = 0;
		previousChar = 0;
		phraseLength = phrase.length();
		StringBuilder buffer = new StringBuilder(phrase);
		for (int i=0; i<phraseLength; i++)
		{
			compChar = buffer.charAt(i);
			convertChar = (int)compChar;
			if ((convertChar == 32) && (firstChar == 1)) 
			{	
				if (previousChar == 32)
				{
					System.out.println("previous character is " + previousChar);
					
					previousChar = convertChar;
				}
				else 
				{
					counter = counter + 1; 
					previousChar = convertChar;
				}// End Inner IF/ELSE
				
			}
			else 
			{
				firstChar = 1;
				previousChar = convertChar;
				
			} // End Outer IF/ELSE
			
			
		} // end FOR LOOP
		return counter;
	}
	

	public String getAllCaps() 
	{
		counter = 1;
		newPhrase = null;
		finalPhrase = null;
		phraseLength = phrase.length();
		StringBuilder buffer = new StringBuilder(phrase);
		for (int i=0; i<phraseLength; i++)
		{
			compChar = buffer.charAt(i);
			convertChar = (int)compChar;
			if ((convertChar >= 97) && (convertChar <= 122))
				{
					newChar = Character.toUpperCase(compChar);
					newPhrase = newPhrase + newChar;
				} else
				{
					newPhrase = newPhrase + compChar;
				}
		}
		finalPhrase = newPhrase.substring(4);
		return finalPhrase;
	}

	public String getAllLowerCase() 
	{
		counter = 1;
		newPhrase = null;
		finalPhrase = null;
		phraseLength = phrase.length();
		StringBuilder buffer = new StringBuilder(phrase);
		for (int i=0; i<phraseLength; i++)
		{
			compChar = buffer.charAt(i);
			convertChar = (int)compChar;
			if ((convertChar >= 41) && (convertChar <= 90))
				{
					newChar = Character.toLowerCase(compChar);
					newPhrase = newPhrase + newChar;
				} else
				{
					newPhrase = newPhrase + compChar;
				}
		}
		finalPhrase = newPhrase.substring(4);
		return finalPhrase;
	}
	
	public String getReverseOrder() 
	{
		counter = 1;
		newPhrase = null;
		finalPhrase = null;
		phraseLength = phrase.length();
		StringBuilder buffer = new StringBuilder(phrase);
		for (int i=phraseLength - 1; i>=0; i--)
		{
			compChar = buffer.charAt(i);
			newPhrase = newPhrase + compChar;
		}
		finalPhrase = newPhrase.substring(4);
		return finalPhrase;
	}
}
